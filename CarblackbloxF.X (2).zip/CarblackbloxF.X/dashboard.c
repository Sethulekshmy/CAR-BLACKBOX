//#include <xc.h>
#include"main.h"
extern char event[9][3];
unsigned char address = 0x00;
extern unsigned char time[9];
 void store_to_eeprom(char time[],unsigned short speed,char *event)
 {
 char data[10];
    
        
    if(address == 100)
    {
            
       for (address = 0; address < 90; address++)
        {
        write_ext_eeprom(address, read_ext_eeprom(address+10));
        }
    }
        data[0]=time[0];
        data[1]=time[1];
        data[2]=time[3];
        data[3]=time[4];
        data[4]=time[6];
        data[5]=time[7];
        data[6]=event[0];
        data[7]=event[1];
        data[8]=speed/10 +'0';
        data[9]=speed%10+ '0';      
          
       for (int i= 0; i < 10; i++)
        {
        write_ext_eeprom(address++,data[i]);
      }
//            address=address + 10;
   
    }
void Dashboard(char key,Status *status) {
    
     unsigned short adc_reg_val;
     adc_reg_val = read_adc(CHANNEL4);
     unsigned short max;
     unsigned short val;
   //  char time[9]="00.00.00";
     static int index;
     if(key==SW1)
     {
         if(index==8)
         {
             index = 2;
         }
         else if(index<7)
         {
             index++;
//             CLEAR_DISP_SCREEN	;
         }
                      store_to_eeprom(time,adc_reg_val,event[index]);

         
     }
     else if(key==SW2)
     {
         if(index==8)
         {
             index=2;
         }
         else if(index>1)
         {
             index--;
//             index = 1;
//             CLEAR_DISP_SCREEN;
         }
                      store_to_eeprom(time,adc_reg_val,event[index]);

          
     }
         else if(key == SW3)
         {
             index = 8;
             store_to_eeprom(time,adc_reg_val,event[index]);
             CLEAR_DISP_SCREEN;
             
             
              
         }
     else if(key == SW4)
         {
             CLEAR_DISP_SCREEN;
             *status = e_Menu;
             return;
         }
     
     
    
     max = 1023/99; 
     val = adc_reg_val/max;
    clcd_print("Time",LINE1(0));
    clcd_print("Ev",LINE1(9));
    clcd_print("Sp",LINE1(14));
    clcd_print(time,LINE2(0));
    clcd_putch((val/10+'0'),LINE2(14));
    clcd_putch((val%10+'0'),LINE2(15));
    clcd_print((event[index]),LINE2(9));
    return;
}
