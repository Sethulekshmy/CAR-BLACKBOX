#include "main.h"
//extern Status status;
void menu(char key, Status *status)
{
    static char menu[][17]={"View_log","Download_log","Clear_log","Set_time"};
    static char menu_index=0;
    static char star_flag=0;
     if(key==SW1) // Scroll up
    {
        
        if(menu_index>0 && star_flag==0)
        {
          
            menu_index--;
            CLEAR_DISP_SCREEN;
        }
        if(star_flag==1)
        {
            star_flag=0;
        }
    }  
    if(key==SW2) // Scroll Down
    {
        
        if(menu_index<2 && star_flag==1)
        {
            menu_index++;
            CLEAR_DISP_SCREEN;
        }
        if(star_flag==0)
        {
            star_flag=1;
        }
    }
     if (key == SW4)
    {
        if (star_flag == 0)
        {
            if (menu_index == 0)
            {
                *status = e_View_log;
                CLEAR_DISP_SCREEN;
                return;
            }
            else if (menu_index == 1)
            {
                *status = e_Download_log;
                CLEAR_DISP_SCREEN;
                return;
            }
            else if (menu_index == 2)
            {
               *status = e_Clear_log;
                CLEAR_DISP_SCREEN;
                star_flag = 0;
                menu_index = 0;
                return;
            }
        }
        else
        {
            if (menu_index + 1 == 1)
            {
                *status = e_Download_log;
                CLEAR_DISP_SCREEN;
                return;
            }
            else if (menu_index + 1 == 2)
            {
                *status = e_Clear_log;
                CLEAR_DISP_SCREEN;
                star_flag = 0;
                menu_index = 0;
                return;
            }
            else if (menu_index + 1 == 3)
            {
                *status = e_Set_time;
                CLEAR_DISP_SCREEN;
                return;
            }
        }
    }
     if(key == SW5)
    {
        CLEAR_DISP_SCREEN;
        *status = e_Dashboard;
        return;
    }
    
    if(star_flag==0)
    {
        clcd_putch('*', LINE1(0));
        clcd_putch(' ', LINE2(0));     
        
    }
    else
    {
        clcd_putch(' ', LINE1(0));
        clcd_putch('*', LINE2(0)); 
    }
    clcd_print(menu[menu_index],LINE1(1));
    clcd_print(menu[menu_index+1],LINE2(1));
}
