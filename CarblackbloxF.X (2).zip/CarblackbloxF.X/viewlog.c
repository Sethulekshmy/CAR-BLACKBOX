#include "main.h"
#include <xc.h>
extern unsigned char address;
 unsigned char index = 0;

void viewlog(char key,Status *status) {
    if(address==0)
    {
        clcd_print("No logs present", LINE1(0));
        clcd_print("                   ", LINE2(0));  
        
    }
          
    else
    {
        if(key==SW2)
            {
              if(index<address/10-1)
              {
                  index++;
              }
            }
            if(key==SW1)
            {
                if(index>0)
                {
                    index--;
                }
            }
           
            
        clcd_print("# Time    EV  SP", LINE1(0));
        clcd_putch(index + '0', LINE2(0));  
        clcd_putch(' ', LINE2(1));

        // Display Time (HH:MM:SS)
        clcd_putch(read_ext_eeprom((index * 10)), LINE2(2));  
        clcd_putch(read_ext_eeprom((index * 10) + 1), LINE2(3));  
        clcd_putch(':', LINE2(4));
        clcd_putch(read_ext_eeprom((index * 10) + 2), LINE2(5));  
        clcd_putch(read_ext_eeprom((index * 10) + 3), LINE2(6));  
        clcd_putch(':', LINE2(7));
        clcd_putch(read_ext_eeprom((index * 10) + 4), LINE2(8));  
        clcd_putch(read_ext_eeprom((index * 10) + 5), LINE2(9));  

        // Display Event Code (EV)
        clcd_putch(' ', LINE2(10));
        clcd_putch(read_ext_eeprom((index * 10) + 6), LINE2(11));  
        clcd_putch(read_ext_eeprom((index * 10) + 7), LINE2(12));  

        // Display Speed (SP)
        clcd_putch(' ', LINE2(13));
        clcd_putch(read_ext_eeprom((index * 10) + 8), LINE2(14));  
        clcd_putch(read_ext_eeprom((index * 10) + 9), LINE2(15));
    }
     if(key == SW5)
            {
                CLEAR_DISP_SCREEN;
                *status = e_Menu;
                return;
            }
    
}
