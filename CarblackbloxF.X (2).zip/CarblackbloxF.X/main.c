/*NAME: S S SETHULEKSHMY
DATE:23-01-2023
DESCRIPTION: CAR BLACK BOX PROJECT
*/
#include "main.h"

extern unsigned char address;
char event[9][3]={"ON" ,"GR" ,"GN", "G1", "G2", "G3","G4","G5","CR"};
unsigned char clock_reg[3];
unsigned char time[9];

void init_config()
{
    init_clcd();
    init_adc();
    init_mkp();
    init_uart();
    init_i2c();
    init_ds1307();
}
void main(void) {
   // Status st
    init_config();
    Status status = e_Dashboard;
     char key=0;
    while(1)
    {
         key=read_matrix_keypad(STATE);
  
    if(status == e_Dashboard)
    {
       get_time();
       Dashboard(key,&status);
    }
     else if(status==e_Menu)
    {
           menu(key,&status);
    }
         else if(status==e_View_log)
    {
//        clcd_print("i am in view",LINE1(0));
//        while(1);
         viewlog(key,&status);
    }
         
       else if(status==e_Download_log)
    {
       download(&status);
    }
   if(status==e_Clear_log)
    {
       clearlog(&status);
    }
    if(status==e_Set_time)
    {
        set_time(key,&status);
    }
     }
     return;
}
void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}