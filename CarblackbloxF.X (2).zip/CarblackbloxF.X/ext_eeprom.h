#ifndef ext_eeprom_H
#define ext_eeprom_H

#define READ		0xA1
#define WRITE		0xA0



//void init_ds1307(void);
void write_ext_eeprom(unsigned char address1,  unsigned char data);
unsigned char read_ext_eeprom(unsigned char address1);

#endif