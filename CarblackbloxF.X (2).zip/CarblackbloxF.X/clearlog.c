#include "main.h"

extern unsigned char address;
extern unsigned char index;  

void clearlog(Status *status)
{
    // Clears entire line

     address = 0;
     index = 0;
    clcd_print("NO logs present", LINE1(0));
    clcd_print("                   ", LINE2(0));  // Clears entire line
    //address = 0;
    // index = 0;

    *status = e_Menu;
    return;
}
