/* 
 * File:   main.h
 * Author: sethu
 *
 * Created on 6 January, 2025, 11:40 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#include<xc.h>
#include"clcd.h"
#include"ext_eeprom.h"
#include"adc.h"
#include"mkp.h"
#include"uart.h"
#include "i2c.h"
#include "ds1307.h"


typedef enum
{
    e_Dashboard ,
    e_Menu,
    e_View_log,
    e_Download_log,
    e_Clear_log,
    e_Set_time
}Status;          
	/* MAIN_H */
////void init_config(void);
//void main(void);
void Dashboard(char key,Status *status);
void store_to_eeprom(char time[],unsigned short speed,char *event);
void menu(char key, Status *status);
void viewlog(char key,Status *status);
void download(Status *status);
void clearlog(Status *status);
void get_time(void);
void set_time(char key ,Status *status);
//void menu(char key);
#endif


