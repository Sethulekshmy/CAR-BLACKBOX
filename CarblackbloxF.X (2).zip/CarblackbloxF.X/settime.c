#include "main.h"

//OPTION state;
char time[9];

void set_time(char key ,Status *status)
{
    char hour = read_ds1307(HOUR_ADDR);
    hour = (hour >> 4)*10 + (hour & 0x0F);
    char min = read_ds1307(MIN_ADDR);
    min = (min >> 4)*10 + (min & 0x0F);
    char sec = read_ds1307(SEC_ADDR);
    sec = (sec >> 4)*10 + (sec & 0x0F);
    char field_flag = 0;
    int delay = 0;
    while(1)
    {
        key = read_matrix_keypad(STATE);
        if(key == SW1)
        {
            if(field_flag == 0)
            {
                if(hour++ == 23)
                    hour = 0;
            }
            if(field_flag == 1)
            {
                if(min++ == 59)
                    min = 0;
            }
            if(field_flag == 2)
            {
                if(sec++ == 59)
                    sec = 0;
            }
        }
        if(key == SW2)
        {
            if(field_flag++ == 2)
                field_flag = 0;
        }
        if(key == SW4)
        {
            hour = ((hour / 10) << 4) | (hour % 10);
            write_ds1307(HOUR_ADDR,hour);
            min = ((min / 10) << 4) | (min % 10);
            write_ds1307(MIN_ADDR,min);
            sec = ((sec / 10) << 4) | (sec % 10);
            write_ds1307(SEC_ADDR,sec);
            *status= e_Menu;
            return;
        }
        if(key == SW5)
        {
            *status = e_Menu;
            return;
        }
        clcd_print("SET TIME", LINE1(0));
        if(delay++ <500)
        {
            clcd_putch('0' +hour / 10,LINE2(1));  
            clcd_putch('0' + hour % 10,LINE2(2));
            clcd_putch(':',LINE2(3));
            clcd_putch('0' + min / 10,LINE2(4));
            clcd_putch('0' + min % 10,LINE2(5));
            clcd_putch(':', LINE2(6));
            clcd_putch('0' + sec / 10,LINE2(7));
            clcd_putch('0' + sec % 10,LINE2(8));
        }
        else
        {
            if(field_flag == 0)
            {
                clcd_putch(' ',LINE2(1));
                clcd_putch(' ',LINE2(2));
                clcd_putch(':',LINE2(3));
                clcd_putch('0' + min / 10,LINE2(4));
                clcd_putch('0' + min % 10,LINE2(5));
                clcd_putch(':', LINE2(6));
                clcd_putch('0' + sec / 10,LINE2(7));
                clcd_putch('0' + sec % 10,LINE2(8));
            }
            else if(field_flag == 1)
            {
                clcd_putch('0' + hour / 10,LINE2(1));  
                clcd_putch('0' + hour % 10,LINE2(2));
                clcd_putch(':',LINE2(3));
                clcd_putch(' ',LINE2(4));
                clcd_putch(' ',LINE2(5));
                clcd_putch(':', LINE2(6));
                clcd_putch('0' + sec / 10,LINE2(7));
                clcd_putch('0' + sec % 10,LINE2(8));
            }
            else if(field_flag == 2)
            {
                clcd_putch('0' +hour / 10,LINE2(1));  
                clcd_putch('0' + hour % 10,LINE2(2));
                clcd_putch(':',LINE2(3));
                clcd_putch('0' + min / 10,LINE2(4));
                clcd_putch('0' + min % 10,LINE2(5));
                clcd_putch(':', LINE2(6));
                clcd_putch(' ',LINE2(7));
                clcd_putch(' ',LINE2(8));
            }
            if(delay == 1000)
                delay = 0;
        }
        
    }
}