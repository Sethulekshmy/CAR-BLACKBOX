#include "main.h"
#include <xc.h>

extern unsigned char address;

void download(Status *status) {
    char data[20];
   unsigned char index = 0;  

    puts("# Time    EV  SP");
 //  putch(address/100+48);putch(address/10%10+48);putch(address+48);
    while (index < (address / 10)) {
        putch(index+48);
        data[0] = index + '0';
        data[1] = ' ';
        data[2] = read_ext_eeprom((index * 10));
        data[3] = read_ext_eeprom((index * 10) + 1);
        data[4] = ':';
        data[5] = read_ext_eeprom((index * 10) + 2);
        data[6] = read_ext_eeprom((index * 10) + 3);
        data[7] = ':';
        data[8] = read_ext_eeprom((index * 10) + 4);
        data[9] = read_ext_eeprom((index * 10) + 5);
        data[10] = ' ';
        data[11] = read_ext_eeprom((index * 10) + 6);
        data[12] = read_ext_eeprom((index * 10) + 7);
        data[13] = ' ';
        data[14] = read_ext_eeprom((index * 10) + 8);
        data[15] = read_ext_eeprom((index * 10) + 9);
        data[16] = '\n';
        data[17] = '\r';
        data[18] = '\0';

        puts(data);
        index++;
    }

    *status = e_Menu;
    return;
}
